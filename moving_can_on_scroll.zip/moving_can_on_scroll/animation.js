can.addEventListener("animationend", removeAnimation);

function removeAnimation() {
  can.classList.remove("slide-in");
  can.classList.add("animate");
}

window.addEventListener('scroll', () => {
    document.body.style.setProperty('--scroll', window.pageYOffset / (document.body.offsetHeight - window.innerHeight));
  }, false);

